self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "59fa690b898ce10edf9e3c14d8cf4b26",
    "url": "./index.html"
  },
  {
    "revision": "5c420b534c864e89aa45",
    "url": "./static/css/2.c2b8765f.chunk.css"
  },
  {
    "revision": "2627fbecd056abe5b120",
    "url": "./static/css/main.cf69715a.chunk.css"
  },
  {
    "revision": "5c420b534c864e89aa45",
    "url": "./static/js/2.4ae81417.chunk.js"
  },
  {
    "revision": "2627fbecd056abe5b120",
    "url": "./static/js/main.71de8ac8.chunk.js"
  },
  {
    "revision": "8c97409f0ee389fe75da",
    "url": "./static/js/runtime~main.d653cc00.js"
  },
  {
    "revision": "25f9c3b1fd9217882c872d3c1e25039e",
    "url": "./static/media/audio_icon.25f9c3b1.jpg"
  },
  {
    "revision": "df6ce005230e8d535fe2ef3c0aad81d7",
    "url": "./static/media/audio_icon_start.df6ce005.jpg"
  }
]);