self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "6445783384522e74f011cf59254cdf66",
    "url": "./index.html"
  },
  {
    "revision": "5c420b534c864e89aa45",
    "url": "./static/css/2.c2b8765f.chunk.css"
  },
  {
    "revision": "6d855d2cc5d1d1c6b350",
    "url": "./static/css/main.cf69715a.chunk.css"
  },
  {
    "revision": "5c420b534c864e89aa45",
    "url": "./static/js/2.4ae81417.chunk.js"
  },
  {
    "revision": "6d855d2cc5d1d1c6b350",
    "url": "./static/js/main.bec09128.chunk.js"
  },
  {
    "revision": "8c97409f0ee389fe75da",
    "url": "./static/js/runtime~main.d653cc00.js"
  },
  {
    "revision": "25f9c3b1fd9217882c872d3c1e25039e",
    "url": "./static/media/audio_icon.25f9c3b1.jpg"
  },
  {
    "revision": "df6ce005230e8d535fe2ef3c0aad81d7",
    "url": "./static/media/audio_icon_start.df6ce005.jpg"
  }
]);